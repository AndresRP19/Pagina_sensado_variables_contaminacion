<?php require_once "vistas/parte_superior.php"?>

<?php

$connect = mysqli_connect("localhost", "root", "", "datos_sensado");
$query = "SELECT id,co,co2,tolueno,nh4 FROM variables WHERE nodo = 'nodo 1'";
$result = mysqli_query($connect, $query);
$datos = '';
while($row = mysqli_fetch_array($result))
{
  $datos .= "{ id:'".$row["id"]."', co:".$row["co"].", co2:".$row["co2"].",tolueno:".$row["tolueno"].", nh4:".$row["nh4"]."}, ";
}

?>

<?php

$connect1 = mysqli_connect("localhost", "root", "", "datos_sensado");
$query1 = "SELECT id,co,co2,tolueno,nh4 FROM variables WHERE nodo = 'nodo 2'";
$result1 = mysqli_query($connect1, $query1);
$datos1 = '';
while($row1 = mysqli_fetch_array($result1))
{
  $datos1 .= "{ id:'".$row1["id"]."', co:".$row1["co"].", co2:".$row1["co2"].",tolueno:".$row1["tolueno"].", nh4:".$row1["nh4"]."}, ";
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <link rel="stylesheet" href="libs/morris.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="libs/morris.min.js" charset="utf-8"></script>


  </head>
  <body>

    <div class="container">
        <h1 align="center">Gráficos</h1>
        <br></br>
        <div class="center">
          <h3 align ="center"> Nodo 1</h3>
          <div id="grafica_2"></div>
        </div>
        <br></br>
        <div class="center">
          <h3 align ="center"> Nodo 2</h3>
          <div id="grafica_3"></div>
        </div>

    </div>

    <script>
    Morris.Line({
    element: 'grafica_2',
    // Chart data records -- each entry in this array corresponds to a point on
    // the chart.
    data: [<?php echo $datos;?>],
    // The name of the data record attribute that contains x-values.
    xkey: 'id',
    // A list of names of data record attributes that contain y-values.
    ykeys: ['co','co2','tolueno','nh4'],
    // Labels for the ykeys -- will be displayed when you hover over the
    // chart.
    xlabels: ['valor de nh4'],
    labels: ['co','co2','tolueno','nh4'],
    resize: true
    })
    </script>

    <script>
    Morris.Line({
    element: 'grafica_3',
    // Chart data records -- each entry in this array corresponds to a point on
    // the chart.
    data: [<?php echo $datos1;?>],
    // The name of the data record attribute that contains x-values.
    xkey: 'id',
    // A list of names of data record attributes that contain y-values.
    ykeys: ['co','co2','tolueno','nh4'],
    // Labels for the ykeys -- will be displayed when you hover over the
    // chart.
    xlabels: ['valor de nh4'],
    labels: ['co','co2','tolueno','nh4'],
    resize: true
    })
    </script>

  </body>
</html>


<?php require_once "vistas/parte_inferior.php"?>
