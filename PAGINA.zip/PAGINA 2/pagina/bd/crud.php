<?php
include_once 'data_conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

// Recepción de los datos enviados mediante POST desde el JS
//que si lo que hay desoyes del ? es verdadero
$co = (isset($_POST['co'])) ? $_POST['co'] : '';
$co2 = (isset($_POST['co2'])) ? $_POST['co2'] : '';
$nh4 = (isset($_POST['nh4'])) ? $_POST['nh4'] : '';
$tolueno = (isset($_POST['tolueno'])) ? $_POST['tolueno'] : '';
$nodo = (isset($_POST['nodo'])) ? $_POST['nodo'] : '';
$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';
$id = (isset($_POST['id'])) ? $_POST['id'] : '';

switch($opcion){
    case 1: //alta
        $consulta = "INSERT INTO variables (co, co2, nh4,tolueno,nodo) VALUES('$co', '$co2', '$nh4','$tolueno','$nodo') ";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();

        $consulta = "SELECT id, co,co2,nh4,tolueno,nodo FROM variables ORDER BY id DESC LIMIT 1";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 2: //modificación
        $consulta = "UPDATE variables SET co='$co', co2='$co2', nh4='$nh4', tolueno='$tolueno', nodo='$nodo' WHERE id='$id' ";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();

        $consulta = "SELECT id, co, co2, nh4, tolueno, nodo FROM variables WHERE id='$id' ";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 3://baja
        $consulta = "DELETE FROM variables WHERE id='$id' ";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        break;
}

print json_encode($data, JSON_UNESCAPED_UNICODE); //enviar el array final en formato json a JS
$conexion = NULL;
