<?php

#php data object PDO

class Conexion{
  public static function Conectar(){

    #si se cambia el hosting solo se modifica los valores de la conexion
    define('servidor','localhost');
    define('nombre_bd','datos_sensado');
    define('usuario', 'root');
    define('password', '');
    $opciones = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
    try{
        $conexion = new PDO("mysql:host=".servidor."; dbname=".nombre_bd, usuario, password, $opciones);
        return $conexion;
    }catch (Exception $e){
        die("El error de Conexión es: ". $e->getMessage());
    }
}
}

 ?>
