<?php require_once "vistas/parte_superior.php"?>

<div clas="container">
  <h1>Contenido Secundaria</h1>
</div>

<?php require_once "vistas/parte_inferior.php"?>
